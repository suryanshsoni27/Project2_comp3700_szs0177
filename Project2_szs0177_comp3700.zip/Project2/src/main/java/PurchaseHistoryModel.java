import java.util.ArrayList;
import java.util.List;

public class PurchaseHistoryModel {
    public List<PurchaseModel> purchases = new ArrayList<PurchaseModel>();
}
